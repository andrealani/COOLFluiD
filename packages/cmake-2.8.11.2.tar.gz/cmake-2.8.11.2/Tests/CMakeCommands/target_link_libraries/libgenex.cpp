
#include "libgenex.h"

int LibGenex::foo()
{
  return 0;
}
