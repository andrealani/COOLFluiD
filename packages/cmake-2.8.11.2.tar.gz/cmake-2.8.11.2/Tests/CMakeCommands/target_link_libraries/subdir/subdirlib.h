
#ifndef SUBDIRLIB_H
#define SUBDIRLIB_H

#include "subdirlib_export.h"

struct SUBDIRLIB_EXPORT SubDirLibObject
{
  int foo() const;
};

#endif
