
#include "subdirlib.h"

int SubDirLibObject::foo() const
{
  return 0;
}
