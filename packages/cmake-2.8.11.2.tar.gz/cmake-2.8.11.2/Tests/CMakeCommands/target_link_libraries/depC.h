
#include "depc_export.h"

#include "depA.h"

struct DEPC_EXPORT DepC
{
  int foo();

  DepA getA();

};
