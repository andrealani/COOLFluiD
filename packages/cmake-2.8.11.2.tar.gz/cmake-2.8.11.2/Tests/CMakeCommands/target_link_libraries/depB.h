
#include "depb_export.h"

struct DEPB_EXPORT DepB
{
  int foo();
};
