
#include "depA.h"

int DepA::foo()
{
  return 0;
}
