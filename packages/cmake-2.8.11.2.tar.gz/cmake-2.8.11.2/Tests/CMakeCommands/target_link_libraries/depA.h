
#include "depa_export.h"

struct DEPA_EXPORT DepA
{
  int foo();
};
