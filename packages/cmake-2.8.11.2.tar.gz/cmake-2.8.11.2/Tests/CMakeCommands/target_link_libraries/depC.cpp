
#include "depC.h"

int DepC::foo()
{
  return 0;
}

DepA DepC::getA()
{
  DepA a;
  return a;
}
