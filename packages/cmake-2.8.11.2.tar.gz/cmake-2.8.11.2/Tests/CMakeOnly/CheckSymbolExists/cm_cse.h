#ifndef _CSE_DUMMY_H
#define _CSE_DUMMY_H

int non_existent_function_for_symbol_test();

#endif
