extern int mylibA();
extern int mylibD();
int main() { return mylibA() + mylibD(); }
