int mylibB() { return -1; }
