int mylibD() { return -1; }
