__declspec(dllexport) int mylibA() { return 1; }
