int foo(void)
{
  return 17;
}
