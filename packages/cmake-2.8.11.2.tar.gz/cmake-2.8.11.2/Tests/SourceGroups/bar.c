int barbar(void)
{
  return 2;
}
