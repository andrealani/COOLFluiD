int baz(void)
{
  return 13;
}
