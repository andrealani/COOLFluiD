int bar(void)
{
  return 42;
}
