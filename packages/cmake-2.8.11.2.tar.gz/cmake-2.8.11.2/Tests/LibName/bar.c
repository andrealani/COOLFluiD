#ifdef _WIN32
__declspec(dllexport)
#endif

extern  void foo()
{
}
