#include <stdio.h>

int tlib6func()
{
  Should not be build unless target directory B, or C are build;
  printf("This is T6\n");
  return 6;
}
