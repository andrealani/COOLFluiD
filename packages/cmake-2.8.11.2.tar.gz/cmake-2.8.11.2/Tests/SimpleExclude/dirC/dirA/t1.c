#include <stdio.h>

int tlib1func()
{
  Should not be build unless target directory A, B, or C are build;
  printf("This is T1\n");
  return 5;
}
