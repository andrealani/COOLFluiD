#include <stdio.h>

int main(int argc, char* argv[])
{
  Should not be build unless target directory A, B, or C are build;
  return 5;
}
