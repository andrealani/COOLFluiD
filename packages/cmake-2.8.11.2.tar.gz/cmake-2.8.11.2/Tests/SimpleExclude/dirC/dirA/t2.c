#include <stdio.h>

int tlib2func()
{
  printf("This is T2\n");
  return 2;
}
