#include <stdio.h>

int tlib8func()
{
  printf("This is T8\n");
  return 8;
}
