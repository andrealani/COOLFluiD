extern int c2();

int d()
{
   return c2()+2;
}

