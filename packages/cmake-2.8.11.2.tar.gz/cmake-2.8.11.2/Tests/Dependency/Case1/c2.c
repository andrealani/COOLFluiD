extern int b2();

int c2()
{
  return b2()+1;
}
