void NoDepAFunction();

void NoDepBFunction()
{
  NoDepAFunction();
}
