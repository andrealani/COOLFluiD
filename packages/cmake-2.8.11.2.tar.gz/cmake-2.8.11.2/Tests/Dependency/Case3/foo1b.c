int foo1b(void) { return 0; }
