void NoDepAFunction();

void NoDepCFunction()
{
  NoDepAFunction();
}
