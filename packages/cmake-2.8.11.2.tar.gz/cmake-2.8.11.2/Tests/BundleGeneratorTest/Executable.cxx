extern void print_message(const char* const Message);

int main(int argc, char* argv[])
{
  print_message("Howdy, World!\n");
  return 0;
}

