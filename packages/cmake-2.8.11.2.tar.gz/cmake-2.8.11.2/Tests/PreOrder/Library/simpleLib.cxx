void simpleLib()
{
}
