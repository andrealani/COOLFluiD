

#ifndef LIB2_HPP
#define LIB2_HPP

#include "lib1.h"

int add1_and_mult2(int num);

#endif
