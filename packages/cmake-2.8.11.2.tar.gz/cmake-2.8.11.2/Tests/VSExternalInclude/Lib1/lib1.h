
#ifndef LIB1_HPP
#define LIB1_HPP

int add1(int num);


#endif
