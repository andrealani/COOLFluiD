class LibCxx1Class
{
public:
#ifdef TEST_FLAG_1
#ifdef TEST_FLAG_2
  static float Method();
#endif
#endif
};
