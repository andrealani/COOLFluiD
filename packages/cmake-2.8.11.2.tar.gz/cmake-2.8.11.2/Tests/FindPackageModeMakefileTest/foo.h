#ifndef FOO_H
#define FOO_H

int foo();

#endif
