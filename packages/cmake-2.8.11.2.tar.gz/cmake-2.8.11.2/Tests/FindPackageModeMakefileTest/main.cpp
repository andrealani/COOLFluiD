#include <stdio.h>
#include <foo.h>

int main()
{
 printf("foo is: %d\n", foo());
 return 0;
}
