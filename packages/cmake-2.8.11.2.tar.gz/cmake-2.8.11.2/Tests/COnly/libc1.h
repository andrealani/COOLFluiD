extern float LibC1Func();
