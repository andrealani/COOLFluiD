extern char* foo;
