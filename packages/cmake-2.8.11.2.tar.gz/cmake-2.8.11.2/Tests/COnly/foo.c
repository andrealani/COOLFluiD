char* foo = "Foo";
