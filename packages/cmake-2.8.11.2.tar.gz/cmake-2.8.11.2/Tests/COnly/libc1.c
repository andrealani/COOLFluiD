float LibC1Func()
{
  return 2.0;
}
