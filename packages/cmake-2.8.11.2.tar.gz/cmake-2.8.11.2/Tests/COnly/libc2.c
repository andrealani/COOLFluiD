#include "libc2.h"

float LibC2Func()
{
  return 1.0;
}
