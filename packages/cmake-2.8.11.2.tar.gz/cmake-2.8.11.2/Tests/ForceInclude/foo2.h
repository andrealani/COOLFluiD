#define FOO_2
