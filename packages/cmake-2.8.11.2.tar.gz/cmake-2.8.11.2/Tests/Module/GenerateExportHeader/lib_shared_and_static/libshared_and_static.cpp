
#include "libshared_and_static.h"

int LibsharedAndStatic::libshared_and_static() const
{
  return 0;
}

int LibsharedAndStatic::libshared_and_static_exported() const
{
  return 0;
}

int LibsharedAndStatic::libshared_and_static_deprecated() const
{
  return 0;
}

int LibsharedAndStatic::libshared_and_static_not_exported() const {
  return 0;
}

int LibsharedAndStatic::libshared_and_static_excluded() const {
  return 0;
}

int LibsharedAndStaticNotExported::libshared_and_static() const
{
  return 0;
}

int LibsharedAndStaticNotExported::libshared_and_static_exported() const
{
  return 0;
}

int LibsharedAndStaticNotExported::libshared_and_static_deprecated() const
{
  return 0;
}

int LibsharedAndStaticNotExported::libshared_and_static_not_exported() const {
  return 0;
}

int LibsharedAndStaticNotExported::libshared_and_static_excluded() const {
  return 0;
}

int LibsharedAndStaticExcluded::libshared_and_static() const
{
  return 0;
}

int LibsharedAndStaticExcluded::libshared_and_static_exported() const
{
  return 0;
}

int LibsharedAndStaticExcluded::libshared_and_static_deprecated() const
{
  return 0;
}

int LibsharedAndStaticExcluded::libshared_and_static_not_exported() const {
  return 0;
}

int LibsharedAndStaticExcluded::libshared_and_static_excluded() const {
  return 0;
}

int libshared_and_static() {
  return 0;
}

int libshared_and_static_exported() {
  return 0;
}

int libshared_and_static_deprecated() {
  return 0;
}

int libshared_and_static_not_exported() {
  return 0;
}

int libshared_and_static_excluded() {
  return 0;
}
