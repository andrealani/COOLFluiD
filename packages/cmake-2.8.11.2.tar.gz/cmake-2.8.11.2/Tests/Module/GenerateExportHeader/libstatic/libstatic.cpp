
#include "libstatic.h"

int Libstatic::libstatic() const
{
  return 0;
}

int Libstatic::libstatic_exported() const
{
  return 0;
}

int Libstatic::libstatic_deprecated() const
{
  return 0;
}

int Libstatic::libstatic_not_exported() const {
  return 0;
}

int Libstatic::libstatic_excluded() const {
  return 0;
}

int LibstaticNotExported::libstatic() const
{
  return 0;
}

int LibstaticNotExported::libstatic_exported() const
{
  return 0;
}

int LibstaticNotExported::libstatic_deprecated() const
{
  return 0;
}

int LibstaticNotExported::libstatic_not_exported() const {
  return 0;
}

int LibstaticNotExported::libstatic_excluded() const {
  return 0;
}

int LibstaticExcluded::libstatic() const
{
  return 0;
}

int LibstaticExcluded::libstatic_exported() const
{
  return 0;
}

int LibstaticExcluded::libstatic_deprecated() const
{
  return 0;
}

int LibstaticExcluded::libstatic_not_exported() const {
  return 0;
}

int LibstaticExcluded::libstatic_excluded() const {
  return 0;
}

int libstatic_exported() {
  return 0;
}

int libstatic_deprecated() {
  return 0;
}

int libstatic_not_exported() {
  return 0;
}

int libstatic_excluded() {
  return 0;
}
