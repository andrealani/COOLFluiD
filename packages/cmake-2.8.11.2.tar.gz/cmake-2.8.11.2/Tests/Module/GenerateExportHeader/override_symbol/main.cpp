
#include "someclass.h"

int main(int, char**)
{
  SomeClass sc;
  sc.someMethod();
  return 0;
}
