
#include "someclass.h"

void SomeClass::someMethod() const
{

}
