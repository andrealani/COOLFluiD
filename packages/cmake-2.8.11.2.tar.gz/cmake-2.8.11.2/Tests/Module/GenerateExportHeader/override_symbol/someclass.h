
#include "somelib_export.h"

class SOMELIB_EXPORT SomeClass
{
public:
  void someMethod() const;
};
