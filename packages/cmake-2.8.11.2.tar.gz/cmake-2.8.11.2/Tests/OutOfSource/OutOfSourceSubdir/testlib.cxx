#include "testlib.h"

float TestLib()
{
  return 1.0;
}
