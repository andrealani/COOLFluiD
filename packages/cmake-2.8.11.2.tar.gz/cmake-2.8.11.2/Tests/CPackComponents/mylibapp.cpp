#include "mylib.h"

int main()
{
  mylib_function();
}
