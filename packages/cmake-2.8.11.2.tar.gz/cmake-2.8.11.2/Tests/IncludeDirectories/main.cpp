#include "Flags.h"
#include "IncDir.h"
#include "SrcProp.h"
#include "TarProp.h"

int main(int argc, char** argv)
{
  return 0;
}
