#ifdef _WIN32
__declspec(dllexport)
#endif
int empty() { return 0; }
