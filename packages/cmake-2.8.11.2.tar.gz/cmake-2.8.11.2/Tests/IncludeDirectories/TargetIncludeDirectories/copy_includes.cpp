
#include "common.h"

int main()
{
  return 0;
}
