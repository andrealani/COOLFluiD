
#include "bar.h"
#include "bat.h"
#include "foo.h"
#include "baz.h"
#include "bang.h"
#include "bing.h"
#include "bung.h"
#include "ting.h"
#include "arguments.h"
#include "list.h"
#include "target.h"

int main(int, char**)
{
  return 0;
}
