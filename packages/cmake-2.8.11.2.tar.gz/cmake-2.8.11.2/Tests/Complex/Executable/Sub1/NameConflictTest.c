int NameConflictTest1()
{
  return 0;
}
