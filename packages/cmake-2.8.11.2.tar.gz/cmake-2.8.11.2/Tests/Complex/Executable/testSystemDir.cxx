#include <testSystemDir.h>

int main() { return foo(); }
