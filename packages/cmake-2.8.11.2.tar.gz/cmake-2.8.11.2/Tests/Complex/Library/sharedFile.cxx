#include "sharedFile.h"

int sharedFunction()
{
  return 1;
}
