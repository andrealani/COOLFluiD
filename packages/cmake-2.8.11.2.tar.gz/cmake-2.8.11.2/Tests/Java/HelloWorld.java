class HelloWorld
{
    public static void main(String args[])
    {
        A a;
        a = new A();
        a.printName();
        System.out.println("Hello World!");
    }
}

