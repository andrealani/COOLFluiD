class A
{
  public A()
    {
    }

  public void printName()
    {
      System.out.println("A");
    }
}
