// The VS6 IDE does not support object name configuration so we need a
// source file with a different name.  Include the real source file.
#include "preprocess.cxx"
