extern int dummy;
