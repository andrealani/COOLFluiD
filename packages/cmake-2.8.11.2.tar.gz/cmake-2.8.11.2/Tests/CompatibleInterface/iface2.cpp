
#include "iface2.h"

int Iface2::foo()
{
  return 0;
}
