
#ifndef IFACE2_H
#define IFACE2_H

#include "iface2_export.h"

class IFACE2_EXPORT Iface2
{
public:
  int foo();
};

#endif
