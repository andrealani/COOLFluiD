extern int foo1();
int bar1() { return foo1(); }
