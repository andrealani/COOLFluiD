int foo1() { return 0; }
