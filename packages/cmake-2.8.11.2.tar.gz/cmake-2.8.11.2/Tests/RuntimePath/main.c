extern int bar1();
int main()
{
  return bar1();
}
