extern int foo2();
int bar2() { return foo2(); }
