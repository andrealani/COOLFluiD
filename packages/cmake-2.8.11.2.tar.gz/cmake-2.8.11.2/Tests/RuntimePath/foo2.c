int foo2() { return 0; }
